# Nymology API Python Wrapper
Nymology seeks deeper meaning within language and between ourselves.
By acquiring structured knowledge spanning disciplines, regions and cultures, we strive towards a singularity of meaning and understanding.

Nymology invites the collection and analysis of idea sets – a set of dimensions used to frame a concept.
The resulting “thesaurus” can be used to populate knowledgebase systems for natural language processing.

On the website, the general public can play games & activities using story templates, idea sets and other meaning structures.

The Nymology API is provided so developers can include the data and methods in their products or services.
Nymology is open source. Developers, please contribute activities or improvements!

http://nymology.org

# FILE STRUCTURE:
# api/__init__.py
# api/nymology.py
# api/README.txt
# api/data/

# API ROOT FOLDER = 'api'
# API DATA FOLDER = 'api/data'

# USING THE WRAPPER:
from nymology import NymologyAPI
nym = NymologyAPI(
    username='gus',
    password='nym'
)

# WRAPPER METHODS:
nym.create(dataset, data)
nym.read(dataset, pk)
nym.update(dataset, pk, data)
nym.delete(dataset, pk)
nym.get_page(dataset, page)
nym.get_data(dataset)
nym.get_file(dataset)
nym.save_file(dataset)
nym.save_database()
nym.endpoints()

# Change the home data folder:
nym = NymologyAPI(home='data')

# Query local Django server:
nym = NymologyAPI(local=True)


##########################
# INGEST DATA INTO DJANGO:
# From a Django shell, load the API & data ingestor:
from api.nymology import NymologyAPI
from ingestor import *
nym = NymologyAPI()

# Either run a full API ingestion..
mass_ingest(nym)

# ..or use saved JSON files
mass_ingest(nym, saved=True)
